import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.junit.Test;
/**
* <strong>WorkGUITesting</strong><br>
* WorkGUITesting is a class to run unit testing of the program 
* 
*
*
* @author  German Cortes Avellaneda
* @version 1.0
* @since   May 15, 2022
*/
public class WorkGUITesting {
	/**
	 * This method will test the to output of the doProcessing methed of WorkGUI class with the predefined sample of testing data.
	 */
	@Test
	public void testWordOccurrences() {
	
		WorkGUI workGui=new WorkGUI();
		ArrayList<Word> wordsList=workGui.getlist();
		ArrayList<Word> testWords=new ArrayList<Word>();
		
		//Test Words 
		Word chamberExpected=new Word("chamber",11);
		Word NevermoreExpected=new Word("Nevermore",10);
		Word LenoreExpected=new Word("Lenore",8);
		testWords.add(chamberExpected);
		testWords.add(NevermoreExpected);
		testWords.add(LenoreExpected);		
		//all three tests
		Word chamberResult=new Word();
		Word NevermoreResult=new Word();
		Word LenoreResult=new Word();
		
		for(Word w:wordsList) {
			if(w.getWord().equalsIgnoreCase("chamber")) {
				chamberResult=w;
				
			break;
			}
		}
		for(Word w:wordsList) {
			if(w.getWord().equalsIgnoreCase("Nevermore")) {
				NevermoreResult=w;
				
			break;
			}
		}
		for(Word w:wordsList) {
			if(w.getWord().equalsIgnoreCase("Lenore")) {
				LenoreResult=w;
				
			break;
			}
		}
	
		assertEquals(chamberExpected.getFrequency(),chamberResult.getFrequency());
		assertEquals(NevermoreExpected.getFrequency(),NevermoreResult.getFrequency());
		assertEquals(LenoreExpected.getFrequency(),LenoreResult.getFrequency());
		
		
	}
}
