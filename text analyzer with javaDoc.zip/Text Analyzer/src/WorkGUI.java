import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

/**
* <strong>WorkGUI</strong>  <br>
* GUI and Processing of the word CONCURRENCY Application.
*
* @author  German Cortes Avellaneda
* @version 1.0
* @since   May 15, 2022
*/
public class WorkGUI extends JFrame {

	/**
	 * Panel to keep Ui components 
	 */
	private JPanel contentPane;
	/**
	 * created and Arraylist for the Words
	 */
	ArrayList<Word> wordsList= new ArrayList<>();

	/**
	 * Launch the application.
	 * @param args parameters to start the program
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WorkGUI frame = new WorkGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * This frame is used to display the top 20 words
	 */
	public WorkGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 577, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		doProcessing();
		JButton btnAnalyzeButton = new JButton("Strat Analyzing");
		btnAnalyzeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					doProcessing();
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}}}
		);
		btnAnalyzeButton.setBounds(5, 5, 551, 23);
		contentPane.add(btnAnalyzeButton);
		
		JButton btnShowTop20Button = new JButton("Show Top 20 Words");
		btnShowTop20Button.setBounds(5, 39, 551, 23);
		contentPane.add(btnShowTop20Button);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(98, 73, 377, 386);
		contentPane.add(textArea);
		btnShowTop20Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Sn	Word	:	frequency ");
				Collections.sort(wordsList);
				String s="Sn	Word	:	frequency ";
				for (int i=1;i<=20;i++) {
					Word wordd=wordsList.get(i);
//					DefaultListModel<String> l2 = new DefaultListModel<>();

					s=s+"\n "+i+" "+wordd.toString();
					
					//System.out.println(i+""+wordd.toString());
			}
				textArea.setText(s);
				System.out.println(s);
			
			}
		});
	}
	/**
	 * This method do the Processing of the text file and count the frequcy of each word and and add it the words list.
	 *
	 */
	public void doProcessing(){
		/** Reading file line by line */
		File file = new File("src/textFile.txt");
		wordsList.clear();
		Scanner scan;
		try {
			scan = new Scanner(file);
		
		System.out.println("Analyzing the text.......");
		
		while (scan.hasNextLine()) {
			String val = scan.nextLine(); // reading line by line
			val=val.replaceAll("[^a-zA-Z0-9]"," ");
			String[] wordsInLine=val.split(" ");
			//System.out.println(val);
			for(String word:wordsInLine) {
			if(wordsList.stream().anyMatch(o -> o.getWord().equals(word))) {
			for(Word w:wordsList) {
			if(w.getWord().equalsIgnoreCase(word)) {
			w.frequency++;
			break;
			}
			}
			}else {
				wordsList.add(new Word(word,1));
			}
			}
			}
		System.out.println("text Analyzing completed.......");
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}
		
	}
	
	/**
	 * This method will be working as getter for the words list.
	 *@return Words list
	 */
	public ArrayList<Word> getlist(){
		return wordsList;
		
	}
}
