/**
* <strong>Word</strong> <br>
* Word is a model class to store and manage words and their frequecy
* 
*
*
* @author  German Cortes Avellaneda
* @version 1.0
* @since   May 15, 2022
*/
public class Word implements Comparable {
	
	String word;
	int frequency;
	/**
	 * Word() is Constractor with no parrameters
	 * 
	 */
	 
	public Word() {
		super();
	}
	/**
	 * Word(String,int) is Constractor with 
	 * @param String Word 
	 * @param Int frequency
	 * 
	 */
	public Word(String word, int frequency) {
		super();
		this.word = word;
		this.frequency = frequency;
	}

	/**
	 * @return String 
	 */
	
	public String getWord() {
		return word;
	}

	
	/**
	 * 
	 * @param  word to set.
	 */
	public void setWord(String word) {
		this.word = word;
	}

/**
 * @return word frequency
 */
	public int getFrequency() {
		return frequency;
	}
	/**
	 * 
	 * @param  frequency to set.
	 */
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	/**
	 * 
	 * @return word  and and frequency of the current object in string.
	 */
	@Override
	public String toString() {
		return "	"+ word + "	:	"+ frequency ;
	}

	@Override
	public int compareTo(Object o) {
	    int compar=((Word)o).getFrequency();
        /* For Ascending order*/
        return compar-this.frequency;

	}
	
	
}
